const mongoose = require("mongoose");

const roleShopSchema = new mongoose.Schema({
  roleId: String, // null for custom
  name: String,
  price: Number,
  stock: Number,
  type: String // "normal" | "custom"
});

module.exports = mongoose.model("RoleShop", roleShopSchema);
