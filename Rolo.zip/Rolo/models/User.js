const mongoose = require("mongoose");

const userSchema = new mongoose.Schema({
  userId: { type: String, unique: true },
  coins: { type: Number, default: 0 },
  dailyQuests: { type: Array, default: [] },
  lastQuestReset: { type: Date, default: null }
});

module.exports = mongoose.model("User", userSchema);
