module.exports = [
  ...Array.from({ length: 30 }, (_, i) => ({
    type: "messages",
    goal: 10 + i,
    reward: 150 + i * 2
  })),
  ...Array.from({ length: 20 }, (_, i) => ({
    type: "reactions",
    goal: 5 + i,
    reward: 180 + i * 3
  })),
  ...Array.from({ length: 20 }, (_, i) => ({
    type: "vc_minutes",
    goal: 5 + i * 2,
    reward: 200 + i * 4
  })),
  ...Array.from({ length: 15 }, (_, i) => ({
    type: "commands",
    goal: 3 + i,
    reward: 170 + i * 3
  })),
  ...Array.from({ length: 15 }, (_, i) => ({
    type: "shop",
    goal: 1 + Math.floor(i / 3),
    reward: 250 + i * 5
  }))
];
