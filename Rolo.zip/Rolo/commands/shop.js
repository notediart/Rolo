const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const RoleShop = require("../models/RoleShop");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("shop")
    .setDescription("View the role shop"),

  async execute(interaction) {
    const items = await RoleShop.find();

    const normal = items.filter(r => r.type === "normal");
    const custom = items.filter(r => r.type === "custom");

    const embed = new EmbedBuilder()
      .setTitle("🛒 Role Shop")
      .setColor("Gold")
      .addFields(
        {
          name: "🎭 Normal Roles",
          value: normal.length
            ? normal.map(r =>
                `<@&${r.roleId}> — 🪙 ${r.price} | Stock: ${r.stock === -1 ? "∞" : r.stock}`
              ).join("\n")
            : "None"
        },
        {
          name: "✨ Custom Roles",
          value: custom.length
            ? custom.map(r =>
                `${r.name} — 🪙 ${r.price} | Stock: ${r.stock}`
              ).join("\n")
            : "None"
        }
      );

    await interaction.reply({ embeds: [embed] });
  }
};
