const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const User = require("../models/User");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("balance")
    .setDescription("Check your coin balance or another user's")
    .addUserOption(option =>
      option
        .setName("user")
        .setDescription("The user to check the balance of")
        .setRequired(false)
    ),

  async execute(interaction) {
    const target = interaction.options.getUser("user") || interaction.user;

    let user = await User.findOne({ userId: target.id });
    if (!user) {
      user = await User.create({ userId: target.id });
    }

    const embed = new EmbedBuilder()
      .setTitle(`${target.username}'s Balance`)
      .setColor("Gold")
      .setDescription(`🪙 Coins: **${user.coins}**`);

    await interaction.reply({ embeds: [embed] });
  }
};
