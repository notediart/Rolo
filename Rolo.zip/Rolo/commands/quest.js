const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const User = require("../models/User");
const generateDailyQuests = require("../utils/generateDailyQuests");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("quest")
    .setDescription("View your daily quests"),

  async execute(interaction) {
    let user = await User.findOne({ userId: interaction.user.id });

    if (!user) {
      user = await User.create({
        userId: interaction.user.id,
        dailyQuests: generateDailyQuests(),
        lastQuestReset: Date.now()
      });
    }

    if (!user.lastQuestReset || Date.now() - user.lastQuestReset > 86400000) {
      user.dailyQuests = generateDailyQuests();
      user.lastQuestReset = Date.now();
      await user.save();
    }

    const embed = new EmbedBuilder()
      .setTitle("🎯 Daily Quests")
      .setColor("Blurple")
      .setDescription(
        user.dailyQuests.map((q, i) => (
          `**${i + 1}. ${q.type.toUpperCase()}**
Progress: ${q.progress}/${q.goal}
Reward: 🪙 ${q.reward}
Status: ${q.completed ? "✅ Completed" : "❌ In Progress"}`
        )).join("\n\n")
      );

    await interaction.reply({ embeds: [embed] });
  }
};
