const { Client, Collection, GatewayIntentBits, REST, Routes } = require("discord.js");
const mongoose = require("mongoose");
const fs = require("fs");
const config = require("./config.json");
const User = require("./models/User");

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ]
});

client.commands = new Collection();

// LOAD COMMANDS
const commandFiles = fs.readdirSync("./commands").filter(f => f.endsWith(".js"));
const commands = [];

for (const file of commandFiles) {
  const command = require(`./commands/${file}`);
  client.commands.set(command.data.name, command);
  commands.push(command.data.toJSON());
}

// REGISTER SLASH COMMANDS
const rest = new REST({ version: "10" }).setToken(config.token);

(async () => {
  await rest.put(
    Routes.applicationGuildCommands(config.clientId, config.guildId),
    { body: commands }
  );
  console.log("✅ Slash commands registered");
})();

// MONGODB
mongoose.connect(config.mongoURI)
  .then(() => console.log("✅ MongoDB connected"))
  .catch(console.error);

// MESSAGE COINS + QUEST PROGRESS
client.on("messageCreate", async message => {
  if (message.author.bot) return;

  let user = await User.findOne({ userId: message.author.id });
  if (!user) user = await User.create({ userId: message.author.id });

  user.coins += 50;

  user.dailyQuests.forEach(q => {
    if (q.type === "messages" && !q.completed) {
      q.progress++;
      if (q.progress >= q.goal) {
        q.completed = true;
        user.coins += q.reward;
      }
    }
  });

  await user.save();
});

// INTERACTIONS
client.on("interactionCreate", async interaction => {
  if (!interaction.isChatInputCommand()) return;

  const command = client.commands.get(interaction.commandName);
  if (!command) return;

  try {
    await command.execute(interaction);
  } catch (err) {
    console.error(err);
    interaction.reply({ content: "❌ Error executing command", ephemeral: true });
  }
});

client.login(config.token);
