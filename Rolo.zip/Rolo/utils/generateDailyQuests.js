const questPool = require("../quests/questPool");

module.exports = function generateDailyQuests() {
  const shuffled = [...questPool].sort(() => 0.5 - Math.random());

  return shuffled.slice(0, 3).map(q => ({
    type: q.type,
    goal: q.goal,
    reward: q.reward,
    progress: 0,
    completed: false
  }));
};

